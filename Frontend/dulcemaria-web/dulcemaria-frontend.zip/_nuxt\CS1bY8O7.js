import{Z as t,R as e}from"./Bbke-0N1.js";const i=t((o,a)=>{if(!localStorage.getItem("auth_token"))return e("/login")});export{i as default};
