export default {
  server: {
    port: 3000
  }
}
