/**
 * Helper temporal para ejecutar migración correctiva de orders
 * ELIMINAR después de usar
 */

require("dotenv").config();
const express = require("express");
const { fixOrdersSchema } = require("../src/migrations/fix-orders");

const app = express();

app.get("/fix-orders-now", async (req, res) => {
  const providedToken = req.query.token || "";
  const expectedToken = process.env.JWT_SECRET || "";
  
  if (!expectedToken || providedToken !== expectedToken) {
    return res.status(403).send("Forbidden");
  }

  console.log("🔧 Fixing orders schema...");
  
  try {
    const result = await fixOrdersSchema();
    
    res.send(`
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Orders Schema Fixed</title>
  <style>
    body { font-family: Arial; max-width: 800px; margin: 50px auto; padding: 20px; }
    .success { background: #d4edda; border: 1px solid #c3e6cb; padding: 20px; border-radius: 5px; }
    h1 { color: #155724; }
  </style>
</head>
<body>
  <div class="success">
    <h1>✅ ORDERS SCHEMA FIXED</h1>
    
    <p><strong>Cambios aplicados: ${result.applied}/${result.total}</strong></p>
    
    <p>Columnas agregadas a orders:</p>
    <ul>
      <li>order_no (BIGINT IDENTITY)</li>
      <li>payment_status (TEXT)</li>
      <li>payment_method (TEXT)</li>
      <li>delivery_method (TEXT)</li>
      <li>delivery_fee_clp (INT)</li>
    </ul>
    
    <h2>Siguiente paso:</h2>
    <ol>
      <li>Cambia Application Startup File a <code>server.js</code></li>
      <li>Restart</li>
      <li>Verifica en phpPgAdmin que las columnas existen</li>
      <li>Avisa para eliminar estos archivos temporales</li>
    </ol>
  </div>
</body>
</html>
    `);
  } catch (error) {
    res.status(500).send(`
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Error</title>
  <style>
    body { font-family: Arial; max-width: 800px; margin: 50px auto; padding: 20px; }
    .error { background: #f8d7da; border: 1px solid #f5c6cb; padding: 20px; border-radius: 5px; }
    h1 { color: #721c24; }
    pre { background: #f4f4f4; padding: 10px; overflow-x: auto; }
  </style>
</head>
<body>
  <div class="error">
    <h1>❌ ERROR</h1>
    <pre>${error.message}\n\n${error.stack}</pre>
  </div>
</body>
</html>
    `);
  }
});

app.get("/", (req, res) => {
  res.send(`
<html>
<body style="font-family: Arial; text-align: center; padding: 50px;">
  <h1>🔧 Fix Orders Helper</h1>
  <p>Para ejecutar la corrección: <code>/fix-orders-now?token=TU_JWT_SECRET</code></p>
</body>
</html>
  `);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Fix Orders Helper on port ${PORT}`);
  console.log(`Access: /fix-orders-now?token=YOUR_JWT_SECRET`);
});
